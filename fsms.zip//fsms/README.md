# SMS Gratis

SMS Gratis menggunakan api web sms.payuterus.biz dengan menggunakan bahasa pemrograman bash shell & python

## Cara Install
```
$pkg install git
$pkg install python
$pip install requests
$git clone ....
$unzip fsms.zip
$cd fsms
$bash run
```


Mod : Unknown240 
2019©

